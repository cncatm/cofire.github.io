---
layout: post
tags: machine-learning python numpy scikit-learn
date: 2014-12-30 13:06
thumbnail: http://placehold.it/100x100
title: A Demo blog
published: true
---

Lorem ipsum dolor sit amet, vivamus quis, urna ligula, aliquet wisi fermentum pellentesque. Vestibulum euismod erat urna vestibulum, per cras tempus bibendum vestibulum, cras a, mus et. Ultrices adipiscing dolor, pellentesque neque nunc eros, sit etiam quam a.

<!--more-->

Lorem ipsum dolor sit amet, vivamus quis, urna ligula, aliquet wisi fermentum pellentesque. Vestibulum euismod erat urna vestibulum, per cras tempus bibendum vestibulum, cras a, mus et. Ultrices adipiscing dolor, pellentesque neque nunc eros, sit etiam quam a. Mattis magna sem sed faucibus, luctus nec egestas mauris et in est, quam libero, facilisis metus tempor dolor aenean, cursus eget venenatis faucibus lectus ante. Et ac qui et scelerisque ac, nulla in, rhoncus a imperdiet, dui ac eu euismod sed sit libero. Felis mauris quis magna felis inceptos, non magna praesent velit enim tellus et. Sed ultricies per ac ipsum pellentesque nascetur, scelerisque habitant eget cras, leo est donec. Repellat viverra pulvinar in, eros sed ipsum est, quis turpis ridiculus porttitor lectus est et, est dapibus arcu non mauris tellus. Consequat neque est donec omnis ut odio, semper a faucibus mus purus.

Tortor a velit elementum, tortor condimentum lectus turpis faucibus, amet praesent id wisi, amet phasellus, scelerisque venenatis a sed massa vitae ac. Sed ridiculus, nec sed nulla. Ut volutpat mauris vestibulum sit risus, viverra at montes nec, luctus hendrerit lectus ipsum, mollis eleifend, ipsum dictumst turpis fringilla. Magna sunt at sed, bibendum risus ut dolorem ut nam sed, non et, integer eros non justo, nulla sed erat diam magna. Sed nulla massa pellentesque. Sed augue fames ut at amet, ultrices ante litora maecenas, quam nullam tristique aenean volutpat rutrum eget, suspendisse vestibulum vel, et massa commodo ante dolor.