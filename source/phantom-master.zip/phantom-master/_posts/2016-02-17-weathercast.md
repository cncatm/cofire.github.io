---
layout: inner
position: left
title: 'Weathercast'
date: 2016-02-20 15:56:00
categories: development
tags: JavaScript AngularJS API Sass
featured_image: 'img/posts/02_weathercast-1130x864-2x.png'
project_link: 'http://github.com/jamigibbs/weathercast'
button_icon: 'github'
button_text: 'Visit Project'
lead_text: 'A simple weather forecast app for your favorite city.'
---
