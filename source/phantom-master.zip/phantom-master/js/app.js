(function(){
  'use strict';

  new WOW().init();
  
})();
